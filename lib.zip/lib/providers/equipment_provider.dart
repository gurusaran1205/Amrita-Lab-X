import 'package:flutter/material.dart';
import '../models/department.dart';
import '../models/lab.dart';
import '../models/equipment.dart';
import '../services/equip_api.dart';
import 'auth_provider.dart';

class EquipmentProvider extends ChangeNotifier {
  AuthProvider authProvider;

  EquipmentProvider({required this.authProvider});

  // Dropdown Data
  List<Department> departments = [];
  List<Lab> labs = [];
  List<Equipment> equipments = [];

  // Selections
  Department? selectedDept;
  Lab? selectedLab;
  Equipment? selectedEquipment;

  // Loading/Error
  bool isLoading = false;
  String? errorMessage;

  /// Helper to always create ApiService with the latest token
  ApiService get _apiService =>
      ApiService(token: authProvider.token); // ✅ Pass token

  Future<void> loadDepartments() async {
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    print("Loading departments...");

    try {
      departments = await _apiService.fetchDepartments();
      print("Departments fetched: $departments");
      // Reset downstream
      labs = [];
      equipments = [];
      selectedDept = null;
      selectedLab = null;
      selectedEquipment = null;
    } catch (e) {
      errorMessage = "Failed to load departments: $e";
      print(errorMessage);
    }

    isLoading = false;
    notifyListeners();
  }

  Future<void> selectDepartment(Department dept) async {
    selectedDept = dept;
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    print("Selected department: ${dept.name}, loading labs...");

    try {
      labs = await _apiService.fetchLabs(dept.id);
      print("Labs fetched: $labs");
      selectedLab = null;
      equipments = [];
      selectedEquipment = null;
    } catch (e) {
      errorMessage = "Failed to load labs: $e";
      print(errorMessage);
    }

    isLoading = false;
    notifyListeners();
  }

  Future<void> selectLab(Lab lab) async {
    selectedLab = lab;
    isLoading = true;
    errorMessage = null;
    notifyListeners();
    print("Selected lab: ${lab.name}, loading equipments...");

    try {
      equipments = await _apiService.fetchEquipment(lab.id);
      print("Equipments fetched: $equipments");
      selectedEquipment = null;
    } catch (e) {
      errorMessage = "Failed to load equipments: $e";
      print(errorMessage);
    }

    isLoading = false;
    notifyListeners();
  }

  void selectEquipment(Equipment equip) {
    selectedEquipment = equip;
    notifyListeners();
  }
}
