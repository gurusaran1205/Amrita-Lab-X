import 'dart:convert';
import 'package:http/http.dart' as http;
import '../models/department.dart';
import '../models/lab.dart';
import '../models/equipment.dart';

class ApiService {
  final String baseUrl = 'http://107.21.163.19';
  final String? token;

  ApiService({this.token});

  Map<String, String> get _headers {
    final headers = {'Content-Type': 'application/json'};
    if (token != null && token!.isNotEmpty) {
      headers['Authorization'] = 'Bearer $token';
    }
    return headers;
  }

  Future<List<Department>> fetchDepartments() async {
    final response =
        await http.get(Uri.parse("$baseUrl/departments"), headers: _headers);
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((e) => Department.fromJson(e)).toList();
    } else {
      throw Exception("Failed to load departments");
    }
  }

  Future<List<Lab>> fetchLabs(String deptId) async {
    final response =
        await http.get(Uri.parse("$baseUrl/labs/$deptId"), headers: _headers);
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((e) => Lab.fromJson(e)).toList();
    } else {
      throw Exception("Failed to load labs");
    }
  }

  Future<List<Equipment>> fetchEquipment(String labId) async {
    final response = await http.get(Uri.parse("$baseUrl/equipment/$labId"),
        headers: _headers);
    if (response.statusCode == 200) {
      final List data = json.decode(response.body);
      return data.map((e) => Equipment.fromJson(e)).toList();
    } else {
      throw Exception("Failed to load equipment");
    }
  }
}
