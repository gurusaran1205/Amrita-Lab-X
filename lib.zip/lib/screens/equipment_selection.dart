import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/equipment_provider.dart';
import '../models/department.dart';
import '../models/lab.dart';
import '../models/equipment.dart';

class EquipmentSelectionPage extends StatefulWidget {
  const EquipmentSelectionPage({super.key});

  @override
  State<EquipmentSelectionPage> createState() => _EquipmentSelectionPageState();
}

class _EquipmentSelectionPageState extends State<EquipmentSelectionPage> {
  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<EquipmentProvider>(context);
    print("Departments loaded: ${provider.departments}");
    print("Labs loaded: ${provider.labs}");
    print("Equipments loaded: ${provider.equipments}");

    return Scaffold(
      appBar: AppBar(title: const Text("Equipment Selection")),
      body: provider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              child: Column(
                children: [
                  // Department Dropdown
                  DropdownButtonFormField<Department>(
                    hint: const Text("Select Department"),
                    value: provider.selectedDept,
                    items: provider.departments
                        .map((dept) => DropdownMenuItem(
                              value: dept,
                              child: Text(dept.name),
                            ))
                        .toList(),
                    onChanged: (dept) {
                      if (dept != null) {
                        provider.selectDepartment(
                            dept); // <-- triggers /api/labs/:id
                      }
                    },
                  ),
                  const SizedBox(height: 20),

                  // Lab Dropdown
                  // Lab Dropdown
                  DropdownButtonFormField<Lab>(
                    hint: const Text("Select Lab"),
                    value: provider.selectedLab,
                    items: provider.labs
                        .map((lab) => DropdownMenuItem(
                              value: lab,
                              child: Text(lab.name),
                            ))
                        .toList(),
                    onChanged: provider.selectedDept == null
                        ? null
                        : (lab) {
                            if (lab != null) {
                              provider.selectLab(
                                  lab); // <-- triggers /api/equipment/:id
                            }
                          },
                  ),

                  const SizedBox(height: 20),

                  // Equipment Dropdown
                  // Equipment Dropdown
                  DropdownButtonFormField<Equipment>(
                    hint: const Text("Select Equipment"),
                    value: provider.selectedEquipment,
                    items: provider.equipments
                        .map((equip) => DropdownMenuItem(
                              value: equip,
                              child: Text(equip.name),
                            ))
                        .toList(),
                    onChanged: provider.selectedLab == null
                        ? null
                        : (equip) {
                            if (equip != null) {
                              provider.selectEquipment(
                                  equip); // <-- only sets final selection
                            }
                          },
                  ),

                  const SizedBox(height: 30),

                  ElevatedButton(
                    onPressed: provider.selectedEquipment == null
                        ? null
                        : () {
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(
                                content: Text(
                                    "Selected: ${provider.selectedDept?.name} > ${provider.selectedLab?.name} > ${provider.selectedEquipment?.name}"),
                              ),
                            );
                          },
                    child: const Text("Confirm Selection"),
                  ),
                ],
              ),
            ),
    );
  }
}
